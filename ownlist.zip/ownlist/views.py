from django.shortcuts import render, redirect
from django.http import HttpResponse  
from ownlist.models import Visitor, Booking, Location , Areg, Vreg, Member
def home_page(request):
     visitors = Visitor.objects.all()
     return render(request, 'homepage.html', {'visitors' : visitors})
   # return render(request, 'index.html')
def new_list(request):                                                            
    svisitor = Visitor.objects.create(vname=request.POST['vvname'],vage=request.POST['vvage'],vcnumber=request.POST['vvcnumber'],vemail=request.POST['vvemail'],vusername=request.POST['vvusername'],vpassword=request.POST['vvpassword'])
    return redirect(f'{svisitor.id}/next')

def view_list(request, visitor_id):
    visitor_ = Visitor.objects.get(id=visitor_id)
    return render(request, 'abooking.html', {'visitor': visitor_})

def add_item(request, visitor_id):
    visitor_ = Visitor.objects.get(id=visitor_id)						
    Booking.objects.create(blocation=request.POST['bblocation'],bdate=request.POST['bbdate'],bpeople=request.POST['bbpeople'],brates=request.POST['bbrates'],visitor=visitor_)
    return redirect(f'/{visitor_.id}/next')
def summer(request):
    return render(request, '3-4.html')
def ABOUT(request):
    return render(request, 'ABOUT.html')
def blog(request):
    return render(request, 'blog.html')
def info(request):
    return render(request, 'info.html')
def next2(request):
    return render(request, '5model .html')

def edit(request, id):
    visitors = Visitor.objects.get(id=id)
    context = {'visitors': visitors}
    return render(request, 'edit.html', context)
 
def update(request, id):
    visitor = Visitor.objects.get(id=id)
    visitor.vname = request.POST['vvname']
    visitor.vage = request.POST['vvage']
    visitor.vcnumber = request.POST['vvcnumber']
    visitor.vusername = request.POST['vvusername']
    visitor.vpassword = request.POST['vvpassword']
    visitor.save()
    return redirect('/')
def delete(request, id):
    visitor = Visitor.objects.get(id=id)
    visitor.delete()
    return redirect('/')     
# Create your views here.
def index(request):
    if request.method == 'POST':
        member = Member(username=request.POST['username'], password=request.POST['password'],  firstname=request.POST['firstname'], lastname=request.POST['lastname'])
        member.save()
        return redirect('/')
    else:
        return render(request, 'index.html')
 
def login(request):
    return render(request, 'login.html')
 
def home(request):
    if request.method == 'POST':
        if Member.objects.filter(username=request.POST['username'], password=request.POST['password']).exists():
            member = Member.objects.get(username=request.POST['username'], password=request.POST['password'])
            return render(request, 'home.html', {'member': member})
        else:
            context = {'msg': 'Invalid username or password'}
            return render(request, 'login.html', context)
'''

def dataManipulation(request):
    personal_information = PERSONAL_INFORMATION(fname="JUDRIE")
    personal_information.save()

    objects = PERSONAL_INFORMATION.objects.all()
    result = 'printing all entries in PERSONAL INFORMATION model : <br>'
    for x in objects:
        res+= x.fname+"<br>"

    pinformation = PERSONAL_INFORMATION.objects.get (fname="JUDRIE")
    res += 'Printing One entry <br>'
    pinformation.delete()

    personal_information = PERSONAL_INFORMATION.objects.get(fname="JUDRIE")
    personal_information.faddress ="Brgy. Summer"
    personal_information.save ()
    res = ""

    qs = PUI.objects.filter(fname="JUDRIE")
    res += "Found : %s results <br>" %qs()

    qs = PERSONAL_INFORMATION.objects.order_by ("faddress")
    for x in qs:
        res += x.fname+ x.faddress + '<br>'


'''
