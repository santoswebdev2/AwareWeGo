#from django.contrib import admin

# Register your models here.
from django.contrib import admin
from ownlist.models import Visitor,Booking,Location,Areg,Vreg

admin.site.register(Visitor)
admin.site.register(Booking)
admin.site.register(Location)
admin.site.register(Areg)
admin.site.register(Vreg)
# Register your models here.
