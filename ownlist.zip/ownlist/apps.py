#from django.apps import AppConfig


#class OwnlistConfig(AppConfig):
  #  name = 'ownlist'
from django.apps import AppConfig


class ownlistConfig(AppConfig):
    name = 'ownlist'
